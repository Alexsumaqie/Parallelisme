# Devoir de Parallélisme

## Membres du groupe

**Nom**: ELAGGOUN

**Prénom**: Aref

**Numéro d'étudiant**: 21910171

----

**Nom**: SUMAQIE

**Prénom**: Ali

**Numéro d'étudiant**: 22001926

